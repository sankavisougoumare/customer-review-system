import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

public class ReviewServer {

    static Connection connection;

    public static void main(String[] args) throws Exception {

        connection = ConnectionFactory.createConnection();

        HttpServer server = HttpServer.create(
                new InetSocketAddress(8081), 0);

        server.createContext("/", exchange -> {

            if (exchange.getRequestMethod().equals("OPTIONS")) {
                addCorsHeaders(exchange);
                exchange.sendResponseHeaders(204, -1);
                exchange.close();
                return;
            }

            String response =
                    "Customer Review Management Backend is running!";

            sendResponse(exchange, response);
        });

        server.createContext("/reviews", ReviewServer::handleReviews);

        server.start();

        System.out.println(
                "Server started at http://localhost:8081");
    }

    static void handleReviews(HttpExchange exchange)
            throws IOException {

        try {

            addCorsHeaders(exchange);

            if (exchange.getRequestMethod().equals("OPTIONS")) {

                exchange.sendResponseHeaders(204, -1);
                exchange.close();
                return;
            }

            String method = exchange.getRequestMethod();

            if (method.equals("GET")) {

                getReviews(exchange);

            } else if (method.equals("POST")) {

                addReview(exchange);

            } else {

                sendResponse(exchange,
                        "Method not supported");
            }

        } catch (Exception e) {

            e.printStackTrace();

            sendResponse(exchange,
                    "Error: " + e.getMessage());
        }
    }

    static void addReview(HttpExchange exchange)
            throws Exception {

        String query =
                exchange.getRequestURI().getQuery();

        String customer =
                getParameter(query, "customer");

        String product =
                getParameter(query, "product");

        String rating =
                getParameter(query, "rating");

        String comment =
                getParameter(query, "comment");

        String reviewId =
                "R" + System.currentTimeMillis();

        Table table = connection.getTable(
                TableName.valueOf("customer_reviews"));

        Put put = new Put(
                Bytes.toBytes(reviewId));

        put.addColumn(
                Bytes.toBytes("review"),
                Bytes.toBytes("customer"),
                Bytes.toBytes(customer));

        put.addColumn(
                Bytes.toBytes("review"),
                Bytes.toBytes("product"),
                Bytes.toBytes(product));

        put.addColumn(
                Bytes.toBytes("review"),
                Bytes.toBytes("rating"),
                Bytes.toBytes(rating));

        put.addColumn(
                Bytes.toBytes("review"),
                Bytes.toBytes("comment"),
                Bytes.toBytes(comment));

        table.put(put);

        table.close();

        sendResponse(
                exchange,
                "Review added successfully! Review ID: "
                        + reviewId);
    }

    static void getReviews(HttpExchange exchange)
            throws Exception {

        Table table = connection.getTable(
                TableName.valueOf("customer_reviews"));

        Scan scan = new Scan();

        ResultScanner scanner =
                table.getScanner(scan);

        StringBuilder response =
                new StringBuilder();

        response.append("[");

        boolean first = true;

        for (Result result : scanner) {

            String id =
                    Bytes.toString(result.getRow());

            String customer =
                    getValue(result, "customer");

            String product =
                    getValue(result, "product");

            String rating =
                    getValue(result, "rating");

            String comment =
                    getValue(result, "comment");

            if (!first) {
                response.append(",");
            }

            response.append("{");

            response.append("\"id\":\"")
                    .append(escapeJson(id))
                    .append("\",");

            response.append("\"customer\":\"")
                    .append(escapeJson(customer))
                    .append("\",");

            response.append("\"product\":\"")
                    .append(escapeJson(product))
                    .append("\",");

            response.append("\"rating\":\"")
                    .append(escapeJson(rating))
                    .append("\",");

            response.append("\"comment\":\"")
                    .append(escapeJson(comment))
                    .append("\"");

            response.append("}");

            first = false;
        }

        response.append("]");

        scanner.close();

        table.close();

        sendResponse(
                exchange,
                response.toString());
    }

    static String getValue(
            Result result,
            String column) {

        byte[] value =
                result.getValue(
                        Bytes.toBytes("review"),
                        Bytes.toBytes(column));

        if (value == null) {
            return "";
        }

        return Bytes.toString(value);
    }

    static String getParameter(
            String query,
            String name) {

        if (query == null) {
            return "";
        }

        for (String parameter :
                query.split("&")) {

            String[] parts =
                    parameter.split("=", 2);

            if (parts.length == 2
                    && parts[0].equals(name)) {

                return URLDecoder.decode(
                        parts[1],
                        StandardCharsets.UTF_8);
            }
        }

        return "";
    }

    static String escapeJson(String value) {

        if (value == null) {
            return "";
        }

        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }

    static void addCorsHeaders(
            HttpExchange exchange) {

        exchange.getResponseHeaders().set(
                "Access-Control-Allow-Origin",
                "*");

        exchange.getResponseHeaders().set(
                "Access-Control-Allow-Methods",
                "GET, POST, OPTIONS");

        exchange.getResponseHeaders().set(
                "Access-Control-Allow-Headers",
                "Content-Type");
    }

    static void sendResponse(
            HttpExchange exchange,
            String response)
            throws IOException {

        addCorsHeaders(exchange);

        exchange.getResponseHeaders().set(
                "Content-Type",
                "application/json");

        byte[] data =
                response.getBytes(
                        StandardCharsets.UTF_8);

        exchange.sendResponseHeaders(
                200,
                data.length);

        OutputStream output =
                exchange.getResponseBody();

        output.write(data);

        output.close();
    }
}