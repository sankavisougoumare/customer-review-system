import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;

public class HBaseConnection {

    public static void main(String[] args) throws Exception {

        Configuration config = HBaseConfiguration.create();

        try (Connection connection = ConnectionFactory.createConnection(config)) {

            System.out.println("Connected to HBase successfully!");

            boolean exists = connection.getAdmin()
                    .tableExists(TableName.valueOf("customer_reviews"));

            System.out.println("customer_reviews table exists: " + exists);
        }
    }
}