const API_URL = "http://localhost:8081";

document
    .getElementById("reviewForm")
    .addEventListener("submit", async function(event) {

        event.preventDefault();

        const customer =
            document.getElementById("customer").value;

        const product =
            document.getElementById("product").value;

        const rating =
            document.getElementById("rating").value;

        const comment =
            document.getElementById("comment").value;

        const url =
            `${API_URL}/reviews?customer=${encodeURIComponent(customer)}&product=${encodeURIComponent(product)}&rating=${encodeURIComponent(rating)}&comment=${encodeURIComponent(comment)}`;

        try {

            const response = await fetch(url, {
                method: "POST"
            });

            const result = await response.text();

            document.getElementById("message").textContent =
                result;

            document.getElementById("reviewForm").reset();

            loadReviews();

        } catch (error) {

            document.getElementById("message").textContent =
                "Unable to connect to backend.";

            console.error(error);
        }
    });


async function loadReviews() {

    try {

        const response =
            await fetch(`${API_URL}/reviews`);

        const reviews =
            await response.json();

        const container =
            document.getElementById("reviewsContainer");

        container.innerHTML = "";

        if (reviews.length === 0) {

            container.innerHTML =
                "<p>No reviews available.</p>";

            return;
        }

        reviews.forEach(review => {

            const card =
                document.createElement("div");

            card.className = "review-card";

            card.innerHTML = `
                <h3>${review.customer}</h3>

                <p class="product">
                    Product / Service: ${review.product}
                </p>

                <p class="rating">
                    ${"★".repeat(Number(review.rating))}
                    ${"☆".repeat(5 - Number(review.rating))}
                </p>

                <p class="comment">
                    ${review.comment}
                </p>
            `;

            container.appendChild(card);
        });

    } catch (error) {

        document.getElementById("reviewsContainer")
            .innerHTML =
            "<p>Unable to load reviews.</p>";

        console.error(error);
    }
}


loadReviews();